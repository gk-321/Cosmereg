$(document).ready(function(){
$('.owl_slide_custom').owlCarousel({
    loop:true,
    margin:0,
    nav:true,
	autoplay:false,
	autoplayTimeout:2000,

    responsive:{
        0:{
            items:1
        }

    }
	
});


$('.owl_slide_two').owlCarousel({
    loop:true,
    margin:30,
    nav:true,
	autoplay:false,
	dots:false,
	autoplayTimeout:2000,

    responsive:{
        0:{
            items:1
        },
		576:{
            items:2
        },
		767:{
            items:3
        },
		900:{
            items:4
        }

    }
});


$('.owl_slide_three').owlCarousel({
    loop:true,
    margin:30,
    nav:true,
	stagePadding: 100,
	autoplay:false,
	dots:false,
	autoplayTimeout:2000,

    responsive:{
        0:{
            items:1
        },
		640:{
            items:2
        },
		1200:{
            items:3
        },


    }
});

$('.owl_slide_four').owlCarousel({
    loop:true,
    margin:30,
    nav:true,
	autoplay:false,
	dots:false,
	autoplayTimeout:2000,

    responsive:{
        0:{
            items:1
        },
		575:{
            items:2
        },
		1000:{
            items:3
        },


    }
});
	$("li.bar_icon svg").click(function(){
		$("#utilize-mobile-menu").toggleClass("show");
		$(".utilize-overlay").toggleClass("show");
	});
	$(".utilize-close").click(function(){
		$("#utilize-mobile-menu").toggleClass("show");
		$(".hamRotate").toggleClass("active");
		$(".utilize-overlay").toggleClass("show");
	});
	$(".utilize-overlay").click(function(){
		$("#utilize-mobile-menu").toggleClass("show");
		$(".hamRotate").toggleClass("active");
		$(".utilize-overlay").toggleClass("show");
	});
	$("li.shop_li span").click(function(){
		$("#utilize-2-cart-menu").toggleClass("show");
		$(".utilize-2-overlay").toggleClass("show");
	});
	$(".utilize-2-close").click(function(){
		$("#utilize-2-cart-menu").toggleClass("show");
		$(".shop_cart").toggleClass("active");
		$(".utilize-2-overlay").toggleClass("show");
	});

});
$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 670) {
        $("header").addClass("header_fixed");
    } else {
        $("header").removeClass("header_fixed");
    }
});
